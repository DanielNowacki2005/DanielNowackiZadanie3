package com.example.yesaplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void change(View view){
        SeekBar seek = findViewById(R.id.seekBar);
        TextView text = findViewById(R.id.font);
        TextView text2 = findViewById(R.id.textView2);
        int size = seek.getProgress() ;
        text2.setTextSize(size);
        text.setText("rozmiar " + Integer.toString(size));

    }
}